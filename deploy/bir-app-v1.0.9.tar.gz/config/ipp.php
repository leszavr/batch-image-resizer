<?php

return [
    /*
    |--------------------------------------------------------------------------
    | File limits
    |--------------------------------------------------------------------------
    */
    'max_file_size_mb'       => (int) env('IPP_MAX_FILE_SIZE_MB', 50),
    'max_files_per_job'      => (int) env('IPP_MAX_FILES_PER_JOB', 100),
    'max_files_free'         => (int) env('IPP_MAX_FILES_FREE', 10),
    'max_file_size_free_mb'  => (int) env('IPP_MAX_FILE_SIZE_FREE_MB', 10),

    /*
    |--------------------------------------------------------------------------
    | Storage
    |--------------------------------------------------------------------------
    */
    'storage_ttl_hours' => (int) env('IPP_STORAGE_TTL_HOURS', 24),

    /*
    |--------------------------------------------------------------------------
    | Queue
    |--------------------------------------------------------------------------
    */
    'queue'         => env('IPP_QUEUE', 'image-processing'),
    'queue_timeout' => (int) env('IPP_QUEUE_TIMEOUT', 300),

    /*
    |--------------------------------------------------------------------------
    | Supported output formats
    |--------------------------------------------------------------------------
    */
    'output_formats' => ['jpg', 'png', 'webp', 'avif', 'gif', 'tiff'],

    /*
    |--------------------------------------------------------------------------
    | Pipeline steps available to users
    |--------------------------------------------------------------------------
    */
    'pipeline_steps' => ['resize', 'rotate', 'flip', 'crop', 'watermark', 'filter'],
];