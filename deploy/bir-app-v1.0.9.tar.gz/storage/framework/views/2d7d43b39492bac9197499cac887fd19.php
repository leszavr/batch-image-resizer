<i data-feather="wind" class="w-7 h-7 text-cyan-400"></i>
<?php /**PATH /home/svv/DEV/BIR/app/resources/views/tools/icons/blur.blade.php ENDPATH**/ ?>