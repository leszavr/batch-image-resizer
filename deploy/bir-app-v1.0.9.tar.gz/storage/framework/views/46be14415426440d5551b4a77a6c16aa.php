<i data-feather="shield" class="w-7 h-7 text-violet-400"></i>
<?php /**PATH /home/svv/DEV/BIR/app/resources/views/tools/icons/watermark.blade.php ENDPATH**/ ?>