<i data-feather="edit-3" class="w-7 h-7 text-violet-400"></i>
<?php /**PATH /home/svv/DEV/BIR/app/resources/views/tools/icons/annotate.blade.php ENDPATH**/ ?>